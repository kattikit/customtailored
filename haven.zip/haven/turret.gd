extends Sprite2D
var pointer = -1
var ballssec = 0
var balldamage = 0
var delay = 0
const ball = preload("res://projectiletd.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	delay += delta
	if delay > 1/(max(ballssec, 0.00000001)):
		var new_ball = ball.instantiate()
		new_ball.speed = balldamage*30
		new_ball.damage = balldamage
		new_ball.global_position = global_position
		add_child(new_ball)
		delay -= 1/(max(ballssec, 0.00000001))
