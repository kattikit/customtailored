extends Label
var money
var wave

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	text = ("Wave:" + str(wave) + "\n$" + str(money) + "\nlives: " + str(Global.lives))
	pass
