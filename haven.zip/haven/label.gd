extends Label


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	text = ("Balls/sec:" + str(snapped(Global.balls/Global.runningtimer, 0.01)) + "\nBall damage:" + str(snapped(Global.velocity/Global.balls/100, 0.01)))
	pass
