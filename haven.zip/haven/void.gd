extends Sprite2D
func type():
	return 5
func cost():
	return 10
