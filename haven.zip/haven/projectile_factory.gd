extends RigidBody2D
var type
@onready var _animated_sprite = $animation
func _ready() -> void:
	visible = true
	_animated_sprite.play("default")

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	visible = true
	var pos = Vector2(floor(global_position.x/100.0), floor(global_position.y/100.0))
	if Global.grid[pos.y][pos.x] != null:
		if global_position.x > pos.x*100 and global_position.x < pos.x*100+100 and global_position.y > pos.y*100 and global_position.y < pos.y*100+100:
			if Global.grid[pos.y][pos.x].type() == 2:
				apply_impulse(Vector2(1, 0).rotated(Global.grid[pos.y][pos.x].rotation)*2500*delta)
			elif Global.grid[pos.y][pos.x].type() == 5:
				queue_free()
				Global.velocity += linear_velocity.length()
				Global.balls += 1
	if global_position.x < 0 or global_position.x > 900 or global_position.y < 0 or global_position.y > 900:
		queue_free()
func _input(event: InputEvent):
	if event is InputEventKey and event.keycode == KEY_SPACE and Global.readyend:
		queue_free()
