extends Area2D
var damage
var speed
@onready var _animated_sprite = $animation
func _ready() -> void:
	visible = true
	_animated_sprite.play("default")


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	position.y -= speed*delta
	if global_position.y < 0 or Global.wavedonee:
		queue_free()
	pass


func _on_area_entered(area: Area2D) -> void:
	if area.is_in_group("enemy"):
		area.damage(damage)
		queue_free()
	pass # Replace with function body.
