extends Sprite2D
var delay = 0
const ball = preload("res://projectile_factory.tscn")

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	delay += delta
	if delay > 0.75:
		var new_ball = ball.instantiate()
		new_ball.linear_velocity = (Vector2(1, 0).rotated(rotation)*500)
		add_child(new_ball)
		delay -= 0.75

func _init() -> void:
	pass

func type():
	return 1
func cost():
	return 20
