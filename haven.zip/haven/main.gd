extends Node
@onready var fac = $level
@onready var td = $TDmap
@onready var g = $Label
func _ready() -> void:
	fac.hide()
	fac.process_mode = Node.PROCESS_MODE_DISABLED
	td.hide()
	td.process_mode = Node.PROCESS_MODE_DISABLED
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Global.mode == "factory":
		fac.show()
		fac.process_mode = Node.PROCESS_MODE_ALWAYS
	else:
		fac.hide()
		fac.process_mode = Node.PROCESS_MODE_DISABLED
	if Global.mode == "td":
		td.show()
		td.process_mode = Node.PROCESS_MODE_ALWAYS
	else:
		td.hide()
		td.process_mode = Node.PROCESS_MODE_DISABLED
	if Global.mode == "lose":
		g.show()
		g.process_mode = Node.PROCESS_MODE_ALWAYS
	else:
		g.hide()
		g.process_mode = Node.PROCESS_MODE_DISABLED
