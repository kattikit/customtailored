extends Node2D
@onready var button = $Button
@onready var button2 = $Button2
@onready var label = $Label
var enemy = preload("res://basicenemy.tscn")
var floor = preload("res://floor.tscn")
var turret = preload("res://turret.tscn")
var designturretcost = 10
var waveduration = 0
var wavenumber = 0
var enemyspawntimer = 0
var placedposition
var dragging
var current
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	for i in range(9):
		for j in range(9):
			var newfloor = floor.instantiate()
			newfloor.position = Vector2(i*100+50, j*100+50)
			add_child(newfloor)
	pass

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	if Global.lives <= 0:
		Global.mode = "lose"
	enemyspawntimer += delta
	waveduration -= delta
	button.wavetimer = waveduration
	label.money = Global.money
	label.wave = wavenumber
	button2.turretcost = floor(designturretcost * 1.2 ** (Global.currentturret+1))
	if waveduration <= 0 and Global.aliveenemies <= 0:
		button.wavedone = true
		button2.wavedone = true
		for i in Global.tdgrid:
			for j in i:
				if j != null:
					j.process_mode = Node.PROCESS_MODE_DISABLED
	elif waveduration > 0:
		button.wavedone = false
		button2.wavedone = false
		if enemyspawntimer > 1/((wavenumber)**(2/3)):
			enemyspawntimer = 0
			var new_enemy = enemy.instantiate()
			new_enemy.position = Vector2(randi_range(0, 8)*100+50, -100)
			new_enemy.speed = wavenumber*5+50
			new_enemy.hp = 10+5*wavenumber
			Global.aliveenemies += 1
			add_child(new_enemy)
		for i in Global.tdgrid:
			for j in i:
				if j != null:
					j.process_mode = Node.PROCESS_MODE_INHERIT
			
		
	pass


func _on_button_pressed() -> void:
	if waveduration <= 0:
		wavenumber += 1
		waveduration = 30
		enemyspawntimer = 0
func _input(event: InputEvent):
	if event is InputEventMouseButton and event.button_index == MOUSE_BUTTON_LEFT:
		placedposition = Vector2(floor(event.position.x/100.0)*100+50, floor(event.position.y/100.0)*100+50)
		if not dragging and event.pressed and Global.grid[((placedposition[1]-50)/100)][((placedposition[0]-50)/100)] == null and 9 > ((placedposition[1]-50)/100) and 9 > ((placedposition[0]-50)/100):
			dragging = true
			if Global.currentturret != -1:
				if Global.turrets[Global.currentturret][2] <= Global.money:
					Global.money -= Global.turrets[Global.currentturret][2]
					var new_launcher = turret.instantiate()
					current = new_launcher
					current.ballssec = Global.turrets[Global.currentturret][1]
					current.balldamage = Global.turrets[Global.currentturret][0]
				else:
					dragging = false
					return
			else:
				dragging = false
				return
			current.position = placedposition
			current.process_mode = Node.PROCESS_MODE_DISABLED
			current.rotation = -PI/2
			add_child(current)
			Global.tdgrid[int(((placedposition[1]-50)/100))][int(((placedposition[0]-50)/100))] = current
		if dragging and not event.pressed:
			dragging = false
			current = null
